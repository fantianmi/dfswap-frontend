export interface OverviewData {
  circSupply?: string
  curPrice?: number
  nextRebase?: number
  scalingFactor?: number
  targetPrice?: number
  totalSupply?: string
}
